# Site-specific additions and overrides for 'opt.openqa-trigger-from-obs.script.rsync.sh'
