export METHOD=rsync
set -e
script/openSUSE:Factory:ToTest.sh
