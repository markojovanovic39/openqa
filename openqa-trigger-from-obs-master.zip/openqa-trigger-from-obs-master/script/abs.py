import scriptgen
import cfg

cfg.header = '''# GENERATED FILE - DO NOT EDIT
set -e
# abstract test config
'''
