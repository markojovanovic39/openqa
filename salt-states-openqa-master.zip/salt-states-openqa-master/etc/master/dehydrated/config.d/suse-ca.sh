CA="https://ca-internal.suse.de/acme/acme/directory"
CHALLENGETYPE="http-01"
WELLKNOWN=/var/lib/acme-challenge
HOOK="${BASEDIR}/hook.sh"
KEY_ALGO=rsa
CONTACT_EMAIL=osd-admins@suse.de
RENEW_DAYS="23"
PRIVATE_KEY_RENEW="no"
