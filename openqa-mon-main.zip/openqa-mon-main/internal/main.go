// shared modules between the different openqa-mon applications
package internal

// VERSION gives the unified version string for all application
const VERSION = "1.5.0"
